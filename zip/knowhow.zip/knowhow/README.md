Knowhow theme 0.6.6
===================
Knowhow is a theme for a GitHub-like knowledge base. [See demo](http://developers.datenstrom.se/themes/knowhow-theme).

[![Screenshot](knowhow-theme.jpg?raw=true)](http://developers.datenstrom.se/themes/knowhow-theme)

How do I install this?
----------------------
1. Download and install [Yellow](https://github.com/datenstrom/yellow/).  
2. Download [knowhow.css](knowhow.css?raw=true) and [knowhow-logo.png](knowhow-logo.png?raw=true), copy them into your `system/themes` folder.  
3. To enable the theme open file `system/config/config.ini` and change `Theme: knowhow`

To uninstall delete the theme files and set default settings.

Designer
--------
Mark Mayberg