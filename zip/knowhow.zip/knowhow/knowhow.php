<?php
// Knowhow theme, https://github.com/datenstrom/yellow-themes/tree/master/knowhow
// Copyright (c) 2013-2017 Datenstrom, https://datenstrom.se
// This file may be used and distributed under the terms of the public license.

class YellowThemeKnowhow
{
	const VERSION = "0.6.13";	
}

$yellow->themes->register("knowhow", "YellowThemeKnowhow", YellowThemeKnowhow::VERSION);
?>