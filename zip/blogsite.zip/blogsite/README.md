Blogsite theme 0.6.6
====================
Blogsite is a basic blogger theme. [See demo](http://developers.datenstrom.se/themes/blogsite-theme).

[![Screenshot](blogsite-theme.jpg?raw=true)](http://developers.datenstrom.se/themes/blogsite-theme)

How do I install this?
----------------------
1. Download and install [Yellow](https://github.com/datenstrom/yellow/).  
2. Download [blogsite.css](blogsite.css?raw=true) and [blogsite-banner.jpg](blogsite-banner.jpg?raw=true), copy them into your `system/themes` folder.  
3. To enable the theme open file `system/config/config.ini` and change `Theme: blogsite`.  

To uninstall delete the theme files and set default settings.

Designer
--------
Mark Mayberg