<?php
// Stockholm theme, https://github.com/datenstrom/yellow-themes/tree/master/stockholm
// Copyright (c) 2013-2018 Datenstrom, https://datenstrom.se
// This file may be used and distributed under the terms of the public license.

class YellowThemeStockholm
{
	const VERSION = "0.7.3";	
}

$yellow->themes->register("stockholm", "YellowThemeStockholm", YellowThemeStockholm::VERSION);
?>
