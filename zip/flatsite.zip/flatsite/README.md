Flatsite theme 0.6.6
====================
Flatsite is a clean business theme. [See demo](http://developers.datenstrom.se/themes/flatsite-theme).

[![Screenshot](flatsite-theme.jpg?raw=true)](http://developers.datenstrom.se/themes/flatsite-theme)

How do I install this?
----------------------
1. Download and install [Yellow](https://github.com/datenstrom/yellow/).  
2. Download [flatsite.css](flatsite.css?raw=true), copy it into your `system/themes` folder.  
3. To enable the theme open file `system/config/config.ini` and change `Theme: flatsite`.  

To uninstall delete the theme files and set default settings.

Designer
--------
Mark Mayberg